#pragma once

int InitLog();

char* UnicodeToAnsi(const wchar_t* szStr);