#include "LocationLog.h"
#include <stdio.h>
#include <Windows.h>
#include <stdlib.h>
#include <shlobj_core.h>
#include <iostream>
#include <string>

using namespace std;

// File Hand
FILE* g_pFile = NULL;

char* UnicodeToAnsi(const wchar_t* szStr)
{
	int nLen = WideCharToMultiByte(CP_ACP, 0, szStr, -1, NULL, 0, NULL, NULL);
	if (nLen == 0)
	{
		return NULL;
	}
	char* pResult = new char[nLen];
	WideCharToMultiByte(CP_ACP, 0, szStr, -1, pResult, nLen, NULL, NULL);
	return pResult;
}

int InitLog()
{
	wstring tempath;
	WCHAR* path = 0;
	char DesktopPath[MAX_PATH] = { 0, };
	HRESULT result = SHGetKnownFolderPath(FOLDERID_Desktop, 0, NULL, &path);
	if (result == S_OK)
	{
		wprintf(L"%s\n", path);
	}
	else
		return -1;

	// DesktopPathLogCat
	tempath = path;
	tempath += L"\\";
	tempath += L"SystemCheckLog.doc";
	CoTaskMemFree(path);

	// wchar --> char
	strcpy(DesktopPath, UnicodeToAnsi(tempath.c_str()));

	g_pFile = fopen(DesktopPath, "wt+");
	if (!g_pFile)
		return -1;

	return 0;
}