#include "SystemInfo.h"
#include <stdio.h>

extern FILE* g_pFile;

int _System(const char * cmd, char *pRetMsg, int msg_len)
{
	FILE * fp;
	char * p = NULL;
	int res = -1;
	char temData[1024] = { 0, };
	if (cmd == NULL || pRetMsg == NULL || msg_len < 0)
	{
		printf("Param Error!\n");
		return -1;
	}
	if ((fp = _popen(cmd, "rt")) == NULL)
	{
		printf("Popen Error!\n");
		return -2;
	}
	else
	{
		Sleep(1);
		memset(pRetMsg, 0, msg_len);
		//get lastest result  
		while (fgets(temData, msg_len, fp) != NULL)
		{
			strcat(pRetMsg, temData);
			printf("%s", temData); //print all info  
		}

		if ((res = _pclose(fp)) == -1)
		{
			printf("close popenerror!\n");
			return -3;
		}
		pRetMsg[strlen(pRetMsg) - 1] = '\0';

		return 0;
	}
}

void GetSystemInfo()
{
	char cmd[] = "systeminfo";
	char a8Result[4096] = { 0 };
	if (g_pFile == NULL)
	{
		printf("û�л�ȡ�����汨����Ϣ\n");
	}
	_System(cmd, a8Result, sizeof(a8Result));
	fprintf(g_pFile, "%s", a8Result);
	fflush(g_pFile);
}