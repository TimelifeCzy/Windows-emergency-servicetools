#pragma once
#include <afxwin.h>
#include <Windows.h>

/*
	Class Name: ProgramEntryPoint
	The Functionality: ������ڵ�
*/

class ProjectEntry : public CWinApp
{
public:
	ProjectEntry();
	virtual ~ProjectEntry() override;
private:
	virtual BOOL InitInstance() override;

private:
};