﻿#pragma once
#include "stdafx.h"
#include "resource.h"
// MasterDlg 对话框

class MasterDlg : public CDialogEx
{
	DECLARE_DYNAMIC(MasterDlg)

public:
	MasterDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~MasterDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();

	/*
		自定义方法
	*/
	int CheckSecSystem();
	virtual BOOL OnInitDialog();
	CStatic m_Networkstatus;
	afx_msg void OnBnClickedRadio1Check();
	CButton m_systeminfo_check;
	
	// 初始化控件状态
	void controlInit();

	// 切换单选状态
	void Radstatus(DWORD id);

	// 卡死解决
	void MfcWinMsgflush(const HANDLE* prochandle);
	void DoEvent();
	CStatic m_PictrueWolf;
	afx_msg void OnStnClickedBitmap();
	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

	/*
		图片
	*/
	CBitmap m_bmp;   //位图
	CBrush m_brush;  //画刷
	CDC m_dc;        //DC对象
	CStatic m_Logbmp;
};
