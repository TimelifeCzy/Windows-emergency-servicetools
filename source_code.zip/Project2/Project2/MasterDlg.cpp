﻿// MasterDlg.cpp: 实现文件
//

#include "stdafx.h"
#include "afxdialogex.h"
#include "MasterDlg.h"
#include "LocationLog.h"
#include "Analysis.h"
#include "AutoStart.h"
#include "Net.h"
#include "NetPortCheck.h"
#include "VirusCharaterCheck.h"
#include "VirusProcessCheck.h"
#include "SystemLog.h"
#include "SystemInfo.h"
#include "SystemUserCheck.h"
#include <iostream>
#include "resource.h"

using namespace std;

// 引入两个全局变量
extern FILE* g_pFile;
extern NETWORKCLIENT netClient;

/*
	解决界面开始的消息回调列表
*/
//自启动回调
DWORD WINAPI ThreadProcAutoStart(
	_In_ LPVOID lpParameter
)
{
	CheckRegisterRun();
	CheckTaskSchedulerRun();
	return 0;
}

// 系统信息采集回调
DWORD WINAPI ThreadProcSysteInfo(
	_In_ LPVOID lpParameter
)
{
	GetSystemInfo();
	return 0;
}

// 进程回调
DWORD WINAPI ThreadProcProcess(
	_In_ LPVOID lpParameter
)
{
	AllProcessCheck();
	AllServicesCheck();
	return 0;
}

// 账户检测
DWORD WINAPI ThreadProcUserCheck(
	_In_ LPVOID lpParameter
)
{
	CheckSystemUser();
	return 0;
}

DWORD WINAPI ThreadProcSystemLog(
	_In_ LPVOID lpParameter
)
{
	GetSystemLogInfo1(5);
	return 0;
}

// 网络检测
DWORD WINAPI ThreadProcNetworkCheck(
	_In_ LPVOID lpParameter
)
{
	EnumTCPTablePid(0, 0, NULL);
	EnumUDPTablePid(0, 0, NULL);
	return 0;
}

// 病毒单项检测
DWORD WINAPI ThreadProcVirusCheck(
	_In_ LPVOID lpParameter
)
{
	VirusMinerPoolCheck();
	return 0;
}

DWORD WINAPI ThreadProcAnalysis(
	_In_ LPVOID lpParameter
)
{
	AutoStartProcNetCheck();
	return 0;
}


/*
	输出与写入日志模板
*/
template<typename T>
T PrintfLog(T buffer)
{
	// printf(buffer);
	fprintf(g_pFile, "%s", buffer);
	fflush(g_pFile);
	return 0;
}

// MasterDlg 对话框
IMPLEMENT_DYNAMIC(MasterDlg, CDialogEx)

MasterDlg::MasterDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
{

}

MasterDlg::~MasterDlg()
{
}

void MasterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_NETWORKSTATUS, m_Networkstatus);
	DDX_Control(pDX, IDC_RADIO1_CHECK, m_systeminfo_check);
	DDX_Control(pDX, IDC_BITMAP, m_PictrueWolf);
	DDX_Control(pDX, IDC_STATIC_LOG, m_Logbmp);
}

BEGIN_MESSAGE_MAP(MasterDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &MasterDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_RADIO1_CHECK, &MasterDlg::OnBnClickedRadio1Check)
	ON_STN_CLICKED(IDC_BITMAP, &MasterDlg::OnStnClickedBitmap)
	ON_WM_PAINT()
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()

// MasterDlg 消息处理程序
BOOL MasterDlg::OnInitDialog()
{
	setlocale(LC_ALL, "chs");
	// controlInit();

	CDialogEx::OnInitDialog();

	// 设置图标
	SetIcon(LoadIcon(AfxGetApp()->m_hInstance, MAKEINTRESOURCE(IDI_ICON1)), FALSE);

	// 设置Bitmap图标 IDC_STATIC_LOG
	// CBitmap* p = new CBitmap();
	// p->LoadBitmapW(IDB_BITMAP1);
	// m_PictrueWolf.SetBitmap((HBITMAP)p->m_hObject);
	CBitmap* d = new CBitmap();
	d->LoadBitmapW(IDB_BITMAP4);
	m_Logbmp.SetBitmap((HBITMAP)d->m_hObject);

	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetRange(0, 100);
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(0);

	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"请点击一键检测");

	/*
		设置背景图
	*/
	//加载位图
	CBitmap bmp;
	bmp.LoadBitmapW(MAKEINTRESOURCE(IDB_BITMAP2));
	//添加位图
	m_bmp.Attach(bmp);
	//创建兼容DC
	CDC* pDc = GetDC();
	m_dc.CreateCompatibleDC(pDc);
	//用完之后释放
	ReleaseDC(pDc);
	//把位图对象选入DC中
	m_dc.SelectObject(&m_bmp);
	//使窗口无效,这样OnPaint函数就会被触发,使之被画出来
	Invalidate(FALSE);

	// 检测网络及云端状态
	if (-1 == InitSocketNet())
	{
		::MessageBox(NULL, L"警告：云端未连接，请将桌面生成的报告交付给专家处理！", L"警告:网络无连接", MB_OK);
		m_Networkstatus.SetWindowTextW(L"云端状态：未连接");
	}
	else
		m_Networkstatus.SetWindowTextW(L"云端状态：已连接");

	return TRUE;
}

void MasterDlg::Radstatus(DWORD id)
{
	for (int i = 0; i < 8; ++i)
	{
		if (id == (1010 + i))
			((CButton*)GetDlgItem(1010 + i))->SetCheck(TRUE);
		else
			((CButton*)GetDlgItem(1010 + i))->SetCheck(FALSE);
	}
}

void MasterDlg::DoEvent()
{
	MSG msg;
	//取消息，检索应用程序的消息队列，PM_REMOVE取过之后从消息队列中移除  
	if (::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))  
	{
		//发消息  
		::TranslateMessage(&msg);
		::DispatchMessage(&msg);
	}
}

void MasterDlg::MfcWinMsgflush(const HANDLE* prochandle)
{
	DWORD dwRet = 0;
	do
	{
		dwRet = ::MsgWaitForMultipleObjects(1, prochandle, FALSE, INFINITE, QS_ALLINPUT);
		if (dwRet != WAIT_OBJECT_0)
		{
			DoEvent();
		}
	} while ((dwRet != WAIT_OBJECT_0) && (dwRet != WAIT_FAILED));

	CloseHandle(*prochandle);
}

// 一键检测
int MasterDlg::CheckSecSystem()
{
	HANDLE procthread = NULL;
	// 初始化一下结构体
	// Init Log and Socket
	if (-1 == InitLog())
	{
		::MessageBox(NULL, L"错误：桌面创建应急服务报告失败！\n请联系右下方服务专家处理问题", L"致命:error", MB_OK);
		return -1;
	}

	fprintf(g_pFile, "%s", "\t\t\t\t\t\t\t应急服务数据报告\n\n");
	netClient.headbufptroffset = ftell(g_pFile);

	// TODO:  在此添加额外的初始化
	this->SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	Radstatus(IDC_RADIO1_CHECK);
	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"第一项：系统信息检测......");
	PrintfLog("系统信息：\n");

	procthread = CreateThread(NULL, 0, ThreadProcSysteInfo, NULL, 0, NULL);
	Sleep(1);
	DoEvent();
	MfcWinMsgflush(&procthread);
	procthread = NULL;

	netClient.systeminfofileptroffset = ftell(g_pFile);
	((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK1))->EnableWindow(TRUE);
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(12);
	this->SetWindowPos(&wndNoTopMost, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	Sleep(1500);

	Radstatus(IDC_RADIO2);
	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"第二项：自启动检测......");
	PrintfLog("\n\n一、自启动采集: \n");

	procthread = CreateThread(NULL, 0, ThreadProcAutoStart, NULL, 0, NULL);
	Sleep(1);
	DoEvent();
	MfcWinMsgflush(&procthread);
	procthread = NULL;


	netClient.autostartfileptroffset = ftell(g_pFile);
	((CButton*)GetDlgItem(IDC_CHECK2))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(TRUE);
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(22);
	Sleep(1500);


	Radstatus(IDC_RADIO3);
	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"第三项：电脑账户检测......");
	PrintfLog("\n\n二、系统用户采集：\n");

	procthread = CreateThread(NULL, 0, ThreadProcUserCheck, NULL, 0, NULL);
	DoEvent();
	MfcWinMsgflush(&procthread);
	procthread = NULL;

	netClient.userinfoptroffset = ftell(g_pFile);
	((CButton*)GetDlgItem(IDC_CHECK3))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK3))->EnableWindow(TRUE);
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(32);
	Sleep(1500);

	Radstatus(IDC_RADIO4);
	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"第四项：系统进程检测......");
	PrintfLog("\n\n三、进程采集： \n");

	procthread = CreateThread(NULL, 0, ThreadProcProcess, NULL, 0, NULL);
	Sleep(1);
	DoEvent();
	MfcWinMsgflush(&procthread);
	procthread = NULL;

	// PrintfLog("\n3.1. 当前进程路径：\n");
	// GetProcessPath();
	netClient.systeminfofileptroffset = ftell(g_pFile);
	((CButton*)GetDlgItem(IDC_CHECK4))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK4))->EnableWindow(TRUE);
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(50);
	Sleep(1500);

	Radstatus(IDC_RADIO5);
	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"第五项：系统日志检测......");
	PrintfLog("\n\n四、系统日志采集：\n");
	
	procthread = CreateThread(NULL, 0, ThreadProcSystemLog, NULL, 0, NULL);
	DoEvent();
	MfcWinMsgflush(&procthread);
	procthread = NULL;

	// GetSystemLogInfo(300);
	netClient.systemlogptroffset = ftell(g_pFile);
	((CButton*)GetDlgItem(IDC_CHECK5))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK5))->EnableWindow(TRUE);
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(60);
	Sleep(1500);

	Radstatus(IDC_RADIO6);
	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"第六项：网络端口检测......");
	PrintfLog("\n\n五、 系统端口采集：\n");

	procthread = CreateThread(NULL, 0, ThreadProcNetworkCheck, NULL, 0, NULL);
	Sleep(1);
	DoEvent();
	MfcWinMsgflush(&procthread);
	procthread = NULL;

	netClient.networkportptroffset = ftell(g_pFile);
	((CButton*)GetDlgItem(IDC_CHECK6))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK6))->EnableWindow(TRUE);
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(70);
	Sleep(1500);

	Radstatus(IDC_RADIO7);
	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"第七项：病毒特征检测......");
	PrintfLog("\n\n六、 病毒单项检测: \n");
	PrintfLog("\t挖矿病毒检测：\n");

	procthread = CreateThread(NULL, 0, ThreadProcVirusCheck, NULL, 0, NULL);
	DoEvent();
	MfcWinMsgflush(&procthread);
	procthread = NULL;

	netClient.virusptroffset = ftell(g_pFile);
	((CButton*)GetDlgItem(IDC_CHECK7))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK7))->EnableWindow(TRUE);
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(87);
	Sleep(1500);

	Radstatus(IDC_RADIO8);
	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"关联分析中......               ");
	PrintfLog("\n\n七、 关联数据分析: \n");
	
	procthread = CreateThread(NULL, 0, ThreadProcAnalysis, NULL, 0, NULL);
	Sleep(1);
	DoEvent();
	MfcWinMsgflush(&procthread);
	procthread = NULL;

	netClient.associationanalysisptroffset = ftell(g_pFile);
	((CButton*)GetDlgItem(IDC_CHECK8))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK8))->EnableWindow(TRUE);
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(100);
	Sleep(1500);

	((CStatic*)GetDlgItem(IDC_STATIC_SHOWSCAN))->SetWindowTextW(L"检测完毕！");

	if (-1 == ClientConnectNet())
	{
		// 失败则弹出
		::MessageBox(NULL, L"警告：数据上传云端失败！\n请将桌面生成的报告交付给专家处理，谢谢！", L"警告:上传失败", MB_OK);
		fclose(g_pFile);
		g_pFile = NULL;
		return -1;
	}

	::MessageBox(NULL, L"重要：数据上传云端成功！\n桌面应急服务报告详细数据已生成！", L"提示", MB_OK);

	fclose(g_pFile);
	g_pFile = NULL;

	return 0;
}

// 控件初始化
void MasterDlg::controlInit()
{
	// 所有的单选框Readonly
	((CButton *)GetDlgItem(IDC_RADIO8))->SetCheck(FALSE);

	// 禁用全部CheckBox
	for (int i = 0; i < 8; ++i)
	{
		((CButton *)GetDlgItem(1002 + i))->SetCheck(FALSE);
		((CButton *)GetDlgItem(1002 + i))->EnableWindow(FALSE);
	}

	// 进度条
	((CProgressCtrl*)GetDlgItem(IDC_PROGRESS1))->SetPos(0);
}

// 一键盘检测
void MasterDlg::OnBnClickedButton1()
{
	// 清空控件状态信息及状态
	controlInit();
	// 调用检测函数
	CheckSecSystem();
}

void MasterDlg::OnBnClickedRadio1Check()
{
	// TODO: 在此添加控件通知处理程序代码
}

void MasterDlg::OnStnClickedBitmap()
{
	// TODO: 在此添加控件通知处理程序代码
}

void MasterDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting
					   // TODO: 在此处添加消息处理程序代码
					   // 不为绘图消息调用 CDialogEx::OnPaint()

	// 画界面
	CRect rect = { 0 };
	GetClientRect(&rect);
	//缩放位图
	BITMAP bm;
	m_bmp.GetBitmap(&bm);
	dc.StretchBlt(0, 0, rect.Width(), rect.Height(),
		&m_dc, 0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY);

	CDialogEx::OnPaint();
}

HBRUSH MasterDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  在此更改 DC 的任何特性
	//像GROUP BOX控件要用FillSolidRect()函数来填充背景，我用SetBkColor()不起作用，不知道为什么
	/*
		IDC_CHECK1      
		IDC_CHECK2      
		IDC_CHECK3      
		IDC_CHECK4      
		IDC_CHECK5      
		IDC_CHECK6      
		IDC_CHECK7      
		IDC_CHECK8      
		IDC_RADIO1_CHECK
		IDC_RADIO2      
		IDC_RADIO3      
		IDC_RADIO4      
		IDC_RADIO5      
		IDC_RADIO6      
		IDC_RADIO7      
		IDC_RADIO8     
		IDC_PROGRESS1
		IDC_STATIC_NETWORKSTATUS
		IDC_STATIC_SHOWSCAN
	*/
	switch (pWnd->GetDlgCtrlID())
	{
	case IDC_CHECK1:
	case IDC_CHECK2:
	case IDC_CHECK3:
	case IDC_CHECK4:
	case IDC_CHECK5:
	case IDC_CHECK6:
	case IDC_CHECK7:
	case IDC_CHECK8:
	case IDC_RADIO1_CHECK:
	case IDC_RADIO2:
	case IDC_RADIO3:
	case IDC_RADIO4:
	case IDC_RADIO5:
	case IDC_RADIO6:
	case IDC_RADIO7:
	case IDC_RADIO8:
	case IDC_PROGRESS1:
	case IDC_STATIC_NETWORKSTATUS:
	case IDC_STATIC_SHOWSCAN:
	case IDC_STATIC_5:
	case IDC_STATIC_6:
	case IDC_STATIC_7:
	{
		pDC->SetBkColor(RGB(255, 255, 255));
		return (HBRUSH)GetStockObject(HOLLOW_BRUSH);
	}
	break;
	default:
		return CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	}
	return hbr;
}
