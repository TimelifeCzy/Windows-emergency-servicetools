#pragma once
#include <Windows.h>


void GetSystemInfo();