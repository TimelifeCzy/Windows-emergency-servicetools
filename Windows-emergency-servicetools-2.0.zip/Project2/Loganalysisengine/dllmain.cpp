﻿// dllmain.cpp : 定义 DLL 应用程序的入口点。
#include "stdafx.h"
#include "Loganalysisengine.h"
#include <stdio.h>
#include <string>

using namespace std;

LOGEVENTCHECK g_logeventcheck = { 0, };

/*
	switch (pevlr->EventType)
	{
		case EVENTLOG_ERROR_TYPE: Type = "错误事件"; break;
		case EVENTLOG_AUDIT_FAILURE: Type = "审核失败"; break;
		case EVENTLOG_AUDIT_SUCCESS: Type = "审核成功"; break;
		case EVENTLOG_INFORMATION_TYPE: Type = "信息事件"; break;
		case EVENTLOG_WARNING_TYPE: Type = "警告事件"; break;
		default:continue;
	}
*/

BOOL CheckRdpBurst()
{
	EVENTLOGRECORD *pevlr = NULL;
	BYTE bBuffer[BUFFER_SIZE] = { 0, };
	DWORD dwRead, dwNeeded, dwThisRecord = 0;
	pevlr = (EVENTLOGRECORD *)&bBuffer;
	string Type;
	// 标志是否找到第一次RDP爆破成功
	int g_rdpstart = 0;
	/*
		day: 时间
		type: 事件类型
	*/
	auto h = OpenEventLog(NULL, L"Security");
	if (h == NULL)
		return FALSE;

	while (ReadEventLog(h,        // event log handle 
		EVENTLOG_FORWARDS_READ |  // reads forward 
		EVENTLOG_SEQUENTIAL_READ, // sequential read 
		0,            // ignored for sequential reads 
		pevlr,        // pointer to buffer 
		BUFFER_SIZE,  // size of buffer 
		&dwRead,      // number of bytes read 
		&dwNeeded))   // bytes in next record 
	{
		while (dwRead > 0)
		{
			// 是登陆信息，而且失败 +1
			if ((pevlr->EventID == 4625) && (pevlr->EventType == EVENTLOG_AUDIT_FAILURE))
				g_Rdpfaliuernumber++;
			
			// 一旦超过3次，意味着可能是RDP爆破 先不考虑运气特别好的情况，如 1/2次 RDP爆破成功....
			// log && success
			if ((g_Rdpfaliuernumber > 3) && (pevlr->EventID == 4624) && (pevlr->EventType == EVENTLOG_AUDIT_SUCCESS))
			{
				// 保存EventId && Time && Descri
				g_logeventcheck.RdpEventId = pevlr->EventID;
				g_logeventcheck.RdpTime = pevlr->TimeWritten;
				UINT uSize = 0;			// 文本大小
				UINT uStringOffset;		// 描述偏移量
				uStringOffset = pevlr->StringOffset;
				uSize = pevlr->DataOffset - pevlr->StringOffset;
				if (uSize > 0)
				{
					LPBYTE pStrings = 0;			// 记录事件
					TCHAR *szExpandedString = 0;	// 描述文本
					UINT uStepOfString = 0;			// 偏移量

					pStrings = (LPBYTE)GlobalAlloc(GPTR, uSize * sizeof(BYTE) + 1);
					memcpy(pStrings, (TCHAR *)pevlr + uStringOffset, uSize);
					pStrings[uSize] = '\0';

					uStepOfString = 0;
					szExpandedString = (TCHAR *)GlobalAlloc(GPTR, (uSize + DESCRIBE_SIZE) * sizeof(TCHAR) + 1);
					for (int i = 0; i < pevlr->NumStrings; i++)
					{
						if (i == 0)
						{
							lstrcpyW(szExpandedString, (TCHAR *)pStrings + uStepOfString);
							if (i < ((UINT)pevlr->NumStrings - 1) )
							{
								lstrcatW(szExpandedString, L",");
							}
						}
						else
						{
							lstrcatW(szExpandedString, (TCHAR *)pStrings + uStepOfString);
						}
						uStepOfString = lstrlenW((TCHAR *)pStrings + uStepOfString) + 1;
					}
				}
				// RDP Start纪录节点成功
				g_rdpstart = 1;
				break;
			}
			dwRead -= pevlr->Length;
			pevlr = (EVENTLOGRECORD *)
				((LPBYTE)pevlr + pevlr->Length);
		}

		if (g_rdpstart)
			break;
		pevlr = (EVENTLOGRECORD *)&bBuffer;
	}
	CloseEventLog(h);
	return TRUE;
}

BOOL CheckProcessExect(unsigned int rdptimenode)
{
	EVENTLOGRECORD *pevlr = NULL;
	BYTE bBuffer[BUFFER_SIZE] = { 0, };
	DWORD dwRead, dwNeeded, dwThisRecord = 0;
	pevlr = (EVENTLOGRECORD *)&bBuffer;
	string Type;
	// 参数校验
	if (rdptimenode == NULL)
		return FALSE;

	// 根据rdptimenode 时间节点进程匹配 在RDP爆破后10分钟以内执行的进程
	auto h = OpenEventLog(NULL, L"Security");

	if (h == NULL)
		return FALSE;

	int index = 0;

	while (ReadEventLog(h,                // event log handle 
		EVENTLOG_FORWARDS_READ |  // reads forward 
		EVENTLOG_SEQUENTIAL_READ, // sequential read 
		0,            // ignored for sequential reads 
		pevlr,        // pointer to buffer 
		BUFFER_SIZE,  // size of buffer 
		&dwRead,      // number of bytes read 
		&dwNeeded))   // bytes in next record 
	{
		// 纪录10条进程数据
		if (index >= 10)
			break;
		while (dwRead > 0)
		{
			// EventProcess 如果时间在RDP爆破之后(假设1分钟之内执行的进程)，纪录进程节点数据
			if ((pevlr->EventID == 4688) && (pevlr->TimeWritten > rdptimenode) && (pevlr->TimeWritten - 10 > rdptimenode))
			{
				g_logeventcheck.ProcessStartEventId[index] = 4688;
				g_logeventcheck.ProcessStartTime[index] = pevlr->TimeWritten;
				// 描述信息

				index++;
				if (index >= 10)
					break;
			}
			
			dwRead -= pevlr->Length;
			pevlr = (EVENTLOGRECORD *)
				((LPBYTE)pevlr + pevlr->Length);
		}
		pevlr = (EVENTLOGRECORD *)&bBuffer;
	}
	CloseEventLog(h);
	return TRUE;
}

BOOL CheckmstscLogin(unsigned int rdptimenode)
{
	EVENTLOGRECORD *pevlr = NULL;
	BYTE bBuffer[BUFFER_SIZE] = { 0, };
	DWORD dwRead, dwNeeded, dwThisRecord = 0;
	pevlr = (EVENTLOGRECORD *)&bBuffer;
	string Type;
	// 参数校验
	if (rdptimenode == NULL)
		return FALSE;

	auto h = OpenEventLog(NULL, L"Security");

	if (h == NULL)
		return FALSE;

	int flag = 0;

	while (ReadEventLog(h,                // event log handle 
		EVENTLOG_FORWARDS_READ |  // reads forward 
		EVENTLOG_SEQUENTIAL_READ, // sequential read 
		0,            // ignored for sequential reads 
		pevlr,        // pointer to buffer 
		BUFFER_SIZE,  // size of buffer 
		&dwRead,      // number of bytes read 
		&dwNeeded))   // bytes in next record 
	{
		// 纪录10条进程数据
		if (flag)
			break;
		while (dwRead > 0)
		{
			// mstsc登陆日志事件: 4776（失败）、4648（登陆）、4624、4672(特殊登陆)
			if ((pevlr->EventID == 1102) && (pevlr->TimeWritten > rdptimenode) && (pevlr->TimeWritten - 10 > rdptimenode))
			{
				g_logeventcheck.LogEventId = 1102;
				g_logeventcheck.LogTime = pevlr->TimeWritten;
				// 描述信息

				flag = 1;
				break;
			}
			dwRead -= pevlr->Length;
			pevlr = (EVENTLOGRECORD *)
				((LPBYTE)pevlr + pevlr->Length);
		}
		pevlr = (EVENTLOGRECORD *)&bBuffer;
	}
	CloseEventLog(h);
	return TRUE;
}

BOOL CheckPowershellExect(unsigned int rdptimenode)
{
	EVENTLOGRECORD *pevlr = NULL;
	BYTE bBuffer[BUFFER_SIZE] = { 0, };
	DWORD dwRead, dwNeeded, dwThisRecord = 0;
	pevlr = (EVENTLOGRECORD *)&bBuffer;
	string Type;
	// 参数校验
	if (rdptimenode == NULL)
		return FALSE;

	auto h = OpenEventLog(NULL, L"Security");

	if (h == NULL)
		return FALSE;

	int flag = 0;

	while (ReadEventLog(h,                // event log handle 
		EVENTLOG_FORWARDS_READ |  // reads forward 
		EVENTLOG_SEQUENTIAL_READ, // sequential read 
		0,            // ignored for sequential reads 
		pevlr,        // pointer to buffer 
		BUFFER_SIZE,  // size of buffer 
		&dwRead,      // number of bytes read 
		&dwNeeded))   // bytes in next record 
	{
		// 纪录10条进程数据
		if (flag)
			break;
		while (dwRead > 0)
		{
			if ((pevlr->EventID == (403 || 600)) && (pevlr->TimeWritten > rdptimenode) && (pevlr->TimeWritten - 10 > rdptimenode))
			{
				g_logeventcheck.PowershellEventId = pevlr->EventID;
				g_logeventcheck.PowershellTime = pevlr->TimeWritten;
				// 描述信息

				flag = 1;
				break;
			}
			dwRead -= pevlr->Length;
			pevlr = (EVENTLOGRECORD *)
				((LPBYTE)pevlr + pevlr->Length);
		}
		pevlr = (EVENTLOGRECORD *)&bBuffer;
	}
	CloseEventLog(h);
	return TRUE;
}

BOOL CheckLogClear(unsigned int rdptimenode)
{
	EVENTLOGRECORD *pevlr = NULL;
	BYTE bBuffer[BUFFER_SIZE] = { 0, };
	DWORD dwRead, dwNeeded, dwThisRecord = 0;
	pevlr = (EVENTLOGRECORD *)&bBuffer;
	string Type;
	// 参数校验u
	if (rdptimenode == NULL)
		return FALSE;

	// 根据rdptimenode 时间节点进程匹配 在RDP爆破后10分钟以内执行的进程
	auto h = OpenEventLog(NULL, L"Security");

	if (h == NULL)
		return FALSE;

	int flag = 0;

	while (ReadEventLog(h,                // event log handle 
		EVENTLOG_FORWARDS_READ |  // reads forward 
		EVENTLOG_SEQUENTIAL_READ, // sequential read 
		0,            // ignored for sequential reads 
		pevlr,        // pointer to buffer 
		BUFFER_SIZE,  // size of buffer 
		&dwRead,      // number of bytes read 
		&dwNeeded))   // bytes in next record 
	{
		if (flag)
			break;
		while (dwRead > 0)
		{
			if ((pevlr->EventID == 1102) && (pevlr->TimeWritten > rdptimenode) && (pevlr->TimeWritten - 10 > rdptimenode))
			{
				g_logeventcheck.LogEventId = 1102;
				g_logeventcheck.LogTime = pevlr->TimeWritten;
				// 描述信息

				flag = 1;
				break;
			}
			dwRead -= pevlr->Length;
			pevlr = (EVENTLOGRECORD *)
				((LPBYTE)pevlr + pevlr->Length);
		}
		pevlr = (EVENTLOGRECORD *)&bBuffer;
	}
	CloseEventLog(h);
	return TRUE;
}

// 规则以 rdp,mstsc,process,logclrea
LOGEVENTCHECK* RuleCorrelationOne()
{
	// 采集的数据传递给界面展示
	CheckRdpBurst();

	if (g_logeventcheck.RdpTime == NULL)
		return FALSE;

	CheckmstscLogin(g_logeventcheck.RdpTime);
	CheckProcessExect(g_logeventcheck.RdpTime);
	CheckLogClear(g_logeventcheck.RdpTime);

	return &g_logeventcheck;
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
	setlocale(LC_ALL, "Chinese-simplified"); // 设置当前的场景为简体中文
    return TRUE;
}

