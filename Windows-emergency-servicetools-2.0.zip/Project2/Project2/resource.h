//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� Project2.rc ʹ��
//
#define IDD_DIALOG1                     101
#define IDB_BITMAP1                     106
#define IDB_BITMAP2                     107
#define IDB_BITMAP3                     108
#define IDB_BITMAP4                     109
#define IDI_ICON1                       111
#define IDB_BITMAP5                     112
#define IDC_BUTTON1                     1001
#define IDC_CHECK1                      1002
#define IDC_CHECK2                      1003
#define IDC_CHECK3                      1004
#define IDC_CHECK4                      1005
#define IDC_CHECK5                      1006
#define IDC_CHECK6                      1007
#define IDC_CHECK7                      1008
#define IDC_CHECK8                      1009
#define IDC_RADIO1_CHECK                1010
#define IDC_RADIO2                      1011
#define IDC_RADIO3                      1012
#define IDC_RADIO4                      1013
#define IDC_RADIO5                      1014
#define IDC_RADIO6                      1015
#define IDC_RADIO7                      1016
#define IDC_RADIO8                      1017
#define IDC_PROGRESS1                   1019
#define IDC_STATIC_NETWORKSTATUS        1020
#define IDC_STATIC_SHOWSCAN             1021
#define IDC_BITMAP                      1022
#define IDC_STATIC_5                    1023
#define IDC_STATIC_6                    1024
#define IDC_STATIC_7                    1025
#define IDC_STATIC_LOG                  1026
#define IDC_BUTTON2_EXTERN              1033
#define IDC_STATIC_9                    1034
#define IDC_TREE1_TIME                  1035
#define IDC_LIST1_EVENT                 1036
#define IDC_RADIO1_HACKRDP              1040
#define IDC_RADIO1_HACKPOWERSHELL       1041
#define IDC_RADIO9_HACKPROCESS          1042
#define IDC_RADIO10_LOGCLEAR            1043
#define IDC_RADIO11_HACKMSCTSC          1044
#define IDC_STATIC_HACK_0               1045
#define IDC_STATIC_HACK_1               1046
#define IDC_STATIC_HACK_2               1047
#define IDC_STATIC_HACK_4               1050
#define IDC_STATIC_HACK_3               1051

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1052
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
