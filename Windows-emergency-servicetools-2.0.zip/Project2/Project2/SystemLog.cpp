#include "SystemLog.h"
#include <iostream>
#include <string>

using namespace std;
extern FILE* g_pFile;


int execmd(char* cmd, char* result) {
	char buffer[128];                         // ������                        
	FILE* pipe = _popen(cmd, "r");            // �ܵ� 

	// �ܵ���ʧ��
	if (!pipe) { return 0; }

	// ���ܵ��еĽ�������0��ʾû�н���
	while (!feof(pipe)) {
		// �ӹܵ��ж�ȡ����
		if (fgets(buffer, 128, pipe)) {
			// ƴ�� char
			strcat(result, buffer);
		}
	}

	//�رչܵ� 
	_pclose(pipe);

	return 1;
}

BOOL GetSystemLogInfo(int count)
{
	char result[0x7ffff] = "";        // ��Ž��
	char cmdcommand[] = "wevtutil qe System / c:300 / rd : true / f : text";

	// ��ȡ�����з���ֵ
	if (execmd(cmdcommand, result) == 1) {
		cout << result << endl;
	}
	return 0;
}

/*
	��ȡӦ�ó�����־����ȫ��־��ϵͳ��־����
	PS C:\Users\Administrator> Get-EventLog -List

	  Max(K) Retain OverflowAction        Entries Log
	  ------ ------ --------------        ------- ---
	  20,480      0 OverwriteAsNeeded         158 Application
	  20,480      0 OverwriteAsNeeded           0 HardwareEvents
		 512      7 OverwriteOlder              0 Internet Explorer
	  20,480      0 OverwriteAsNeeded           0 Key Management Service
												  Security
	  20,480      0 OverwriteAsNeeded         317 System
		 512      7 OverwriteOlder              0 Windows Azure
	  15,360      0 OverwriteAsNeeded           7 Windows PowerShell
		WCHAR wzLogNameApp[] = L"Application";
		WCHAR wzLogNameSec[] = L"Security";
		WCHAR wzLogNameSys[] = L"System";
		WCHAR wzLogNamePower[] = L"Windows PowerShell";
		HANDLE hEventApp = OpenEventLog(NULL, wzLogNameApp);
		HANDLE hEventSec = OpenEventLog(NULL, wzLogNameSec);
		HANDLE hEventSys = OpenEventLog(NULL, wzLogNameSys);
*/
BOOL GetSystemLogInfo1(int count)
{
	HANDLE h;
	EVENTLOGRECORD *pevlr;
	BYTE bBuffer[BUFFER_SIZE];
	DWORD dwRead, dwNeeded, dwThisRecord = 0;

	// Open the Application event log. 

	h = OpenEventLog(NULL,              // use local computer 
		L"Security");					// source name 
	if (h == NULL)
	{
		printf("Could not open the Application event log.");
		return FALSE;
	}

	pevlr = (EVENTLOGRECORD *)&bBuffer;

	// Opening the event log positions the file pointer for this 
	// handle at the beginning of the log. Read the records 
	// sequentially until there are no more. 

	/*
		��ȡ24Сʱ����
	*/
	string Type, pchar;
	
	while (ReadEventLog(h,                // event log handle 
		EVENTLOG_FORWARDS_READ |  // reads forward 
		EVENTLOG_SEQUENTIAL_READ, // sequential read 
		0,            // ignored for sequential reads 
		pevlr,        // pointer to buffer 
		BUFFER_SIZE,  // size of buffer 
		&dwRead,      // number of bytes read 
		&dwNeeded))   // bytes in next record 
	{
		// printf("ֻ��ӡ10��ʾ�鿴��������̫��\n");
		ULONG nCount = 0;
		while (nCount < count)
		{
			++nCount;
			// Print the event identifier, type, and source name. 
			// The source name is just past the end of the 
			// formal structure. 

			//�¼�����
			switch (pevlr->EventType)
			{
				case EVENTLOG_ERROR_TYPE: Type = "�����¼�"; break;
				case EVENTLOG_AUDIT_FAILURE: Type = "���ʧ��"; break;
				case EVENTLOG_AUDIT_SUCCESS: Type = "��˳ɹ�"; break;
				case EVENTLOG_INFORMATION_TYPE: Type = "��Ϣ�¼�"; break;
				case EVENTLOG_WARNING_TYPE: Type = "�����¼�"; break;
				default:continue;
			}

			printf("%02d  Event ID: 0x%08X ",
				dwThisRecord++, pevlr->EventID);
			fprintf(g_pFile, "%02d  Event ID: 0x%08X ", dwThisRecord++, pevlr->EventID);
			wprintf(L"EventType: %s Source: %s\n",
				Type, (LPSTR)((LPBYTE)pevlr +
					sizeof(EVENTLOGRECORD)));
			fwprintf(g_pFile, L"EventType: %s Source: %s\n", Type, (LPSTR)((LPBYTE)pevlr + sizeof(EVENTLOGRECORD)));
			fflush(g_pFile);
			// dwRead -= pevlr->Length;
			pevlr = (EVENTLOGRECORD *)
				((LPBYTE)pevlr + 0x126 + 0x1c);
		}

		pevlr = (EVENTLOGRECORD *)&bBuffer;
	}
	CloseEventLog(h);

	return TRUE;
}