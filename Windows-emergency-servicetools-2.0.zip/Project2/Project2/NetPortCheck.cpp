#include "NetPortCheck.h"
#include "Analysis.h"
#include <iphlpapi.h>
#include <tlhelp32.h>
#include <Windows.h>
#include <stdlib.h>
#include <psapi.h>
#include <stdio.h>
#include <atlstr.h>
#include <iostream>
#include <iphlpapi.h>
#include <vector>


#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "ws2_32.lib")

using namespace std;

extern vector<AUTOPROCESSCHECK> AutoProc;
extern DWORD g_NetInfoindex;
extern FILE* g_pFile;

DWORD EnumTCPTable()
{
	PMIB_TCPTABLE pTcpTable = NULL;
	DWORD dwSize = 0;
	DWORD dwRetVal = ERROR_SUCCESS;

	struct   in_addr rip;
	struct   in_addr lip;
	char  szrip[32] = { 0 };
	char  szlip[32] = { 0 };

	//���pTcpTable����Ҫ����ʵ����,dwSize
	if (GetTcpTable(pTcpTable, &dwSize, TRUE) == ERROR_INSUFFICIENT_BUFFER)
	{
		pTcpTable = (MIB_TCPTABLE*)malloc((UINT)dwSize);
	}
	else
		return dwRetVal;

	printf("Active Connections\n\n");
	printf("  Proto\t%-24s%-24s%s\n", "Local Address", "Foreign Address", "State");

	if ((dwRetVal = GetTcpTable(pTcpTable, &dwSize, TRUE)) == NO_ERROR)
	{
		for (int i = 0; i < (int)pTcpTable->dwNumEntries; i++)
		{
			rip.S_un.S_addr = pTcpTable->table[i].dwRemoteAddr;
			lip.S_un.S_addr = pTcpTable->table[i].dwLocalAddr;
			//�����˿ڣ�Զ�������˿�Ϊ0����������������ֵ�ģ���֪��������ô���ǵ�
			if (pTcpTable->table[i].dwState == MIB_TCP_STATE_LISTEN)
				pTcpTable->table[i].dwRemotePort = 0;

			//dwLocalPort��dwRemotePort �������ֽ�
			_snprintf(szlip, sizeof(szlip), "%s:%d", inet_ntoa(lip), htons((u_short)pTcpTable->table[i].dwLocalPort));
			_snprintf(szrip, sizeof(szrip), "%s:%d", inet_ntoa(rip), htons((u_short)pTcpTable->table[i].dwRemotePort));
			printf("  TCP\t%-24s%-24s%s\n", szlip, szrip, TcpState[pTcpTable->table[i].dwState]);
		}
	}
	else
	{
		printf("\tCall to GetTcpTable failed.\n");

		LPVOID lpMsgBuf;

		if (FormatMessage(
			FORMAT_MESSAGE_ALLOCATE_BUFFER |
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			dwRetVal,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR)&lpMsgBuf,
			0,
			NULL))
		{
			printf("\tError: %s", lpMsgBuf);
		}
		LocalFree(lpMsgBuf);
	}
	// GlobalFree(pTcpTable);
	if (pTcpTable != NULL) {
		free(pTcpTable);
		pTcpTable = NULL;
	}
	return dwRetVal;
}

DWORD EnumUDPTable()
{
	PMIB_UDPTABLE pUdpTable = NULL;
	DWORD dwSize = 0;
	DWORD dwRetVal = ERROR_SUCCESS;

	// struct   in_addr rip;
	struct   in_addr lip;
	// char  szrip[32] = {0};
	char  szlip[32] = { 0 };

	//���pUdpTable����Ҫ����ʵ����,dwSize
	if (GetUdpTable(pUdpTable, &dwSize, TRUE) == ERROR_INSUFFICIENT_BUFFER)
	{
		pUdpTable = (MIB_UDPTABLE*)malloc((UINT)dwSize);
	}
	else
		return dwRetVal;

	printf("Active Connections\n\n");
	printf("  Proto\t%-24s%-24s\n", "Local Addr", "Local Port");

	if ((dwRetVal = GetUdpTable(pUdpTable, &dwSize, TRUE)) == NO_ERROR)
	{
		for (int i = 0; i < (int)pUdpTable->dwNumEntries; i++)
		{
			// rip.S_un.S_addr = pUdpTable->table[i].dwRemoteAddr;
			lip.S_un.S_addr = pUdpTable->table[i].dwLocalAddr;
			//�����˿ڣ�Զ�������˿�Ϊ0����������������ֵ�ģ���֪��������ô���ǵ�
			// if (pUdpTable->table[i].dwState == MIB_Udp_STATE_LISTEN)   
			// pUdpTable->table[i].dwRemotePort = 0;

			//dwLocalPort��dwRemotePort �������ֽ�
			_snprintf(szlip, sizeof(szlip), "%s:%d", inet_ntoa(lip), htons((u_short)pUdpTable->table[i].dwLocalPort));
			// _snprintf(szrip,sizeof(szrip),"%s:%d",inet_ntoa(rip),htons((u_short)pTcpTable->table[i].dwRemotePort));
			// printf("  TCP\t%-24s%-24s%s\n",szlip,szrip,TcpState[pTcpTable->table[i].dwState]);
			printf("  UDP\t%-24s\n", szlip);
		}
	}
	else
	{

		LPVOID lpMsgBuf;

		if (FormatMessage(
			FORMAT_MESSAGE_ALLOCATE_BUFFER |
			FORMAT_MESSAGE_FROM_SYSTEM |
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			dwRetVal,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR)&lpMsgBuf,
			0,
			NULL))
		{
			printf("\tError: %s", lpMsgBuf);
		}
		LocalFree(lpMsgBuf);
	}
	// GlobalFree(pUdpTable);
	if (pUdpTable != NULL) {
		free(pUdpTable);
		pUdpTable = NULL;
	}
	return dwRetVal;
}

DWORD EnumTCPTablePid(int flag, DWORD pid, PVOID AutStrAddress)
{
	PMIB_TCPTABLE_OWNER_PID pTcpTable(NULL);
	DWORD dwSize(0);
	struct   in_addr rip;
	struct   in_addr lip;
	char  szrip[32] = { 0 };
	char  szlip[32] = { 0 };
	char PidString[20] = { '\0' };
	if (GetExtendedTcpTable(pTcpTable, &dwSize, TRUE, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0) == ERROR_INSUFFICIENT_BUFFER)
		pTcpTable = (MIB_TCPTABLE_OWNER_PID *)new char[dwSize];//���·��仺����

	if (GetExtendedTcpTable(pTcpTable, &dwSize, TRUE, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0) != NO_ERROR)
	{
		delete pTcpTable;
		return 0;
	}

	int nNum = (int)pTcpTable->dwNumEntries; //TCP���ӵ���Ŀ
	if (flag == 0)
	{
		fprintf(g_pFile, "%s", "Active Connections\n\n");
		fprintf(g_pFile, "Proto\t%-24s%-24s%-18s%s\n", "Local Address", "Foreign Address", "State", "PID");
	}

	AUTOPROCESSCHECK* data = (AUTOPROCESSCHECK*)AutStrAddress;

	for (int i = 0; i < nNum; i++)
	{

		rip.S_un.S_addr = pTcpTable->table[i].dwRemoteAddr;
		lip.S_un.S_addr = pTcpTable->table[i].dwLocalAddr;
		//�����˿ڣ�Զ�������˿�Ϊ0����������������ֵ�ģ���֪��������ô���ǵ�
		if (pTcpTable->table[i].dwState == MIB_TCP_STATE_LISTEN)
			pTcpTable->table[i].dwRemotePort = 0;

		//dwLocalPort��dwRemotePort �������ֽ�
		_snprintf(szlip, sizeof(szlip), "%s:%d", inet_ntoa(lip), htons((u_short)pTcpTable->table[i].dwLocalPort));
		_snprintf(szrip, sizeof(szrip), "%s:%d", inet_ntoa(rip), htons((u_short)pTcpTable->table[i].dwRemotePort));
		_ultoa(pTcpTable->table[i].dwOwningPid, PidString, 10);

		if (flag == 0)
		{
			fprintf(g_pFile, "  TCP\t%-24s%-24s%-18s%s\n", szlip, szrip, TcpState[pTcpTable->table[i].dwState], PidString);
		}
		else if (flag == 1)
		{
			// �ж�Pid�Ƿ����
			if (pTcpTable->table[i].dwOwningPid == pid)
			{
				// ����ý��̵�����˿���Ϣ
				sprintf(data->ProcNetInfo[g_NetInfoindex], "TCP\t%-24s%-24s%-18s%s\n", szlip, szrip, TcpState[pTcpTable->table[i].dwState], PidString);
				g_NetInfoindex++;
				break;
			}
		}

	}
	delete pTcpTable;
	return 1;
}

DWORD EnumUDPTablePid(int flag, DWORD pid, PVOID AutStrAddress)
{
	PMIB_UDPTABLE_OWNER_PID pUdpTable(NULL);
	DWORD dwSize(0);
	struct   in_addr lip;
	char  szrip[32] = { 0 };
	char  szlip[32] = { 0 };
	char PidString[20] = { '\0' };
	if (GetExtendedUdpTable(pUdpTable, &dwSize, TRUE, AF_INET, UDP_TABLE_OWNER_PID, 0) == ERROR_INSUFFICIENT_BUFFER)
		pUdpTable = (MIB_UDPTABLE_OWNER_PID *)new char[dwSize];//���·��仺����
	if (GetExtendedUdpTable(pUdpTable, &dwSize, TRUE, AF_INET, UDP_TABLE_OWNER_PID, 0) != NO_ERROR)
	{
		delete pUdpTable;
		return 0;
	}
	int nNum = (int)pUdpTable->dwNumEntries; //TCP���ӵ���Ŀ

	AUTOPROCESSCHECK* data = (AUTOPROCESSCHECK*)AutStrAddress;
	for (int i = 0; i < nNum; i++)
	{

		lip.S_un.S_addr = pUdpTable->table[i].dwLocalAddr;

		//dwLocalPort��dwRemotePort �������ֽ�
		_snprintf(szlip, sizeof(szlip), "%s:%d", inet_ntoa(lip), htons((u_short)pUdpTable->table[i].dwLocalPort));
		_ultoa(pUdpTable->table[i].dwOwningPid, PidString, 10);

		if (flag == 0)
		{
			fprintf(g_pFile, "  UCP\t%-24s%-24s%-18s%s\n", szlip, szrip, " ", PidString);
		}
		else if (flag == 1)
		{
			// �ж�Pid�Ƿ����
			if (pUdpTable->table[i].dwOwningPid == pid)
			{
				// ����ý��̵�����˿���Ϣ
				sprintf(data->ProcNetInfo[g_NetInfoindex], "UCP\t%-24s%-24s%-18s%s\n", szlip, szrip, " ", PidString);
				g_NetInfoindex++;
				break;
			}
		}
	}
	delete pUdpTable;

	return 1;
}