#define WIN32_LEAN_AND_MEAN
#include "Net.h"
#include "LocationLog.h"
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#include <iostream>
#include <shlobj_core.h>
#pragma comment(lib, "Ws2_32.lib")

using namespace std;
extern FILE* g_pFile;
NETWORKCLIENT netClient;

int __cdecl InitSocketNet()
{

	WORD wVersionRequested;
	WSADATA wsaData;
	int err;

	/* Use the MAKEWORD(lowbyte, highbyte) macro declared in Windef.h */
	wVersionRequested = MAKEWORD(2, 2);

	err = WSAStartup(wVersionRequested, &wsaData);
	if (err != 0)
		return -1;

	/* Confirm that the WinSock DLL supports 2.2.*/
	/* Note that if the DLL supports versions greater    */
	/* than 2.2 in addition to 2.2, it will still return */
	/* 2.2 in wVersion since that is the version we      */
	/* requested.                                        */

	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2) {
		WSACleanup();
		return -1;
	}

	SOCKET ConnectSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (SOCKET_ERROR == ConnectSocket)
		return -1;

	SOCKADDR_IN addrClient;
	addrClient.sin_family = AF_INET;
	addrClient.sin_port = htons(27015);
	addrClient.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
	/*
	int connect(SOCKET sock,                      //����ͨѶ���׽���������
				const struct sockaddr *serv_addr, //�洢��������IP��port�Ľṹ��
				int addrlen                       //�ṹ��ĳ���
				);
	*/
	auto iResult = connect(ConnectSocket, (SOCKADDR*)&addrClient, sizeof(SOCKADDR));
	if (iResult == SOCKET_ERROR) {
		iResult = closesocket(ConnectSocket);
		if (iResult == SOCKET_ERROR)
			wprintf(L"closesocket function failed with error: %ld\n", WSAGetLastError());
		WSACleanup();
		return -1;
	}

	// ��һ�������Ǽ���������״̬
	closesocket(ConnectSocket);

	return 0;
}

int ClientConnectNet()
{
	SOCKET ConnectSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (SOCKET_ERROR == ConnectSocket)
		return -1;

	SOCKADDR_IN addrClient;
	addrClient.sin_family = AF_INET;
	addrClient.sin_port = htons(27015);
	addrClient.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
	/*
	int connect(SOCKET sock,                      //����ͨѶ���׽���������
				const struct sockaddr *serv_addr, //�洢��������IP��port�Ľṹ��
				int addrlen                       //�ṹ��ĳ���
				);
	*/
	auto iResult = connect(ConnectSocket, (SOCKADDR*)&addrClient, sizeof(SOCKADDR));
	if (iResult == SOCKET_ERROR) {
		iResult = closesocket(ConnectSocket);
		if (iResult == SOCKET_ERROR)
			return -1;
		WSACleanup();
		return -1;
	}

	// ��ȡ�ļ�������
	wstring tempath;
	WCHAR* path = 0;
	char DesktopPath[MAX_PATH] = { 0, };
	HRESULT result = SHGetKnownFolderPath(FOLDERID_Desktop, 0, NULL, &path);
	if (result == S_OK)
	{
		wprintf(L"%s\n", path);
	}
	else
		return -1;

	// DesktopPathLogCat
	tempath = path;
	tempath += L"\\";
	tempath += L"SystemCheckLog.doc";
	CoTaskMemFree(path);

	// wchar --> char
	strcpy(DesktopPath, UnicodeToAnsi(tempath.c_str()));

	HANDLE nFile = CreateFileA(DesktopPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL);

	if (!nFile)
		printf("��־����ʧ��\n");

	DWORD fSize = 0;
	char* sendbuf = NULL;
	fSize = GetFileSize(nFile, NULL);
	sendbuf = (char*)malloc(fSize + 1);
	memset(sendbuf, 0, fSize + 1);

	strcpy(netClient.requestfllag, "InsertSqlSystemCheckbuf");
	netClient.filesize = fSize;

	send(ConnectSocket, (char *)&netClient, sizeof(NETWORKCLIENT), 0);
	recv(ConnectSocket, sendbuf, 20, 0);
	if (!strcmp("�ƶ˽������ݳɹ�!", sendbuf))
	{
		printf("%s\n", sendbuf);
		fread(sendbuf, fSize, 1, g_pFile);
		send(ConnectSocket, sendbuf, sizeof(sendbuf) + 1, 0);
	}

	Sleep(1000);
	free(sendbuf);
	closesocket(ConnectSocket);
	Sleep(1000);
	WSACleanup();
	return 0;
}