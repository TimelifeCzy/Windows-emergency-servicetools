#include "AutoStart.h"
#include "Analysis.h"
#include <iostream>
#include <vector>
#include <comdef.h>
//  Include the task header file.
#include <taskschd.h>
#pragma comment(lib, "taskschd.lib")
#pragma comment(lib, "comsupp.lib")

using namespace std;

// ��������
extern vector<AUTOPROCESSCHECK> AutoProc;
extern FILE* g_pFile;

// ����Xml��ĳ����������ĸ�ʽ
void XmlCommandAn(const wchar_t* source, wchar_t* deststr)
{
	DWORD index_head = 0;
	DWORD index_tail = 0;
	// ����<Command
	for (int i = 0; i < 0x1024; i++)
	{
		// <Command>F:\\360zip\360zipUpdate.exe</Command>
		if ((source[i] == '<') && (source[i + 1] == 'C') && (source[i + 2] == 'o') && (source[i + 3] == 'm'))
		{
			// ��ȡִ�в�����ʵλ��
			index_head = i + 9;
		}

		if ((source[i] == '<') && (source[i + 1] == '/') && (source[i + 2] == 'C') && (source[i + 3] == 'o'))
		{
			index_tail = i;
			if ((index_tail - index_head) >= 3)
			{
				// ����<Command> xxxxx </Command>
				wmemcpy(deststr, &source[index_head], (index_tail - index_head));
				break;
			}
		}
	}

	// ���Ҳ��� <Arguments>/detectupdate</Arguments>
	for (int i = index_tail; i < 0x1024; i++)
	{
		// <Command>F:\\360zip\360zipUpdate.exe</Command>
		if ((source[i] == '<') && (source[i + 1] == 'A') && (source[i + 2] == 'r') && (source[i + 3] == 'g'))
		{
			// ��ȡִ�в�����ʵλ��
			index_head = i + 11;
		}

		if ((source[i] == '<') && (source[i + 1] == '/') && (source[i + 2] == 'A') && (source[i + 3] == 'r'))
		{
			index_tail = i;
			if ((index_tail - index_head) >= 1)
			{
				// ƴ�� <Command> + <Arguments>
				int nCommandSize = lstrlenW(deststr);
				deststr[nCommandSize] = ' ';
				wmemcpy(&deststr[nCommandSize + 1], &source[index_head], (index_tail - index_head));
				break;
			}
		}
	}
}

/*
	��ȡע�����ֵ���ݣ������ʾ�û����ϴ����ƶ�
		HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run
		HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Run
		HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Runonce
		HKEY_LOCAL_MACHINE\SOFTWARE\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Run
*/
BOOL CheckRegisterRun()
{
	fprintf(g_pFile, "%s", "ע�����⣺\n");
	HKEY hKey;
	DWORD dwType = 0;
	DWORD dwBufferSize = MAXBYTE;
	DWORD dwKeySize = MAXBYTE;
	WCHAR szValueName[MAXBYTE] = { 0 };
	WCHAR szValueKey[MAXBYTE] = { 0 };
	AUTOPROCESSCHECK ProAu = { 0, };
	int i = 0;
	int j = 0;

	if (RegOpenKey(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", &hKey) != ERROR_SUCCESS)
		printf("û���ҵ�SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run \n");
	else
	{
		while (TRUE)
		{
			int rect = RegEnumValue(hKey, i, szValueName, &dwBufferSize, NULL, &dwType, (LPBYTE)szValueKey, &dwKeySize);
			if (rect == ERROR_NO_MORE_ITEMS)
			{
				break;
			}
			i++;
			j++;
			dwBufferSize = MAXBYTE;
			dwKeySize = MAXBYTE;
			// ���浽ȫ��List
			lstrcpyW(ProAu.RegName, szValueName);
			lstrcpyW(ProAu.RegKey, szValueKey);
			AutoProc.push_back(ProAu);
			wprintf(L"Name: %s\n", szValueName);
			wprintf(L"Key: %s\n", szValueKey);
			fwprintf(g_pFile, L"Name: %s\n", szValueName);
			fwprintf(g_pFile, L"Key: %s\n", szValueKey);
			fflush(g_pFile);
			ZeroMemory(szValueName, MAXBYTE);
			ZeroMemory(szValueKey, MAXBYTE);
		}
		RegCloseKey(hKey);
	}

	i = 0;
	j = 0;
	dwType = 0;
	hKey = 0;
	if (RegOpenKey(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Runonce", &hKey) != ERROR_SUCCESS)
		printf("û���ҵ�SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Runonce \n");
	else
	{
		while (TRUE)
		{
			int rect = RegEnumValue(hKey, i, szValueName, &dwBufferSize, NULL, &dwType, (LPBYTE)szValueKey, &dwKeySize);
			if (rect == ERROR_NO_MORE_ITEMS)
			{
				break;
			}
			i++;
			j++;
			dwBufferSize = MAXBYTE;
			dwKeySize = MAXBYTE;
			lstrcpyW(ProAu.RegName, szValueName);
			lstrcpyW(ProAu.RegKey, szValueKey);
			AutoProc.push_back(ProAu);
			wprintf(L"Name: %s\n", szValueName);
			wprintf(L"Key:\t%s\n", szValueKey);
			fwprintf(g_pFile, L"Name: %s\n", szValueName);
			fwprintf(g_pFile, L"Key:\t%s\n", szValueKey);
			fflush(g_pFile);
			ZeroMemory(szValueName, MAXBYTE);
			ZeroMemory(szValueKey, MAXBYTE);
		}
		RegCloseKey(hKey);
	}


	i = 0;
	j = 0;
	dwType = 0;
	hKey = 0;
	if (RegOpenKey(HKEY_CURRENT_USER, L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", &hKey) != ERROR_SUCCESS)
		printf("û���ҵ� HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run \n ");
	else
	{
		while (TRUE)
		{
			int rect = RegEnumValue(hKey, i, szValueName, &dwBufferSize, NULL, &dwType, (LPBYTE)szValueKey, &dwKeySize);
			if (rect == ERROR_NO_MORE_ITEMS)
			{
				break;
			}
			i++;
			j++;
			dwBufferSize = MAXBYTE;
			dwKeySize = MAXBYTE;
			wprintf(L"Name: %s\n", szValueName);
			wprintf(L"Key:\t%s\n", szValueKey);
			lstrcpyW(ProAu.RegName, szValueName);
			lstrcpyW(ProAu.RegKey, szValueKey);
			AutoProc.push_back(ProAu);
			fwprintf(g_pFile, L"Name: %s\n", szValueName);
			fwprintf(g_pFile, L"Key:\t%s\n", szValueKey);
			fflush(g_pFile);
			ZeroMemory(szValueName, MAXBYTE);
			ZeroMemory(szValueKey, MAXBYTE);
		}
		RegCloseKey(hKey);
	}

	i = 0;
	j = 0;
	dwType = REG_SZ | REG_EXPAND_SZ;

	hKey = 0;
	DWORD flags = 0;
	if (RegOpenKey(HKEY_LOCAL_MACHINE, L"SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run", &hKey) != ERROR_SUCCESS)
		printf("û���ҵ�Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Run \n");
	else
	{
		while (TRUE)
		{
			int rect = RegEnumValue(hKey, i, szValueName, &dwBufferSize, NULL, &dwType, (LPBYTE)szValueKey, &dwKeySize);
			if (rect == ERROR_NO_MORE_ITEMS)
			{
				break;
			}
			i++;
			j++;
			dwBufferSize = MAXBYTE;
			dwKeySize = MAXBYTE;

			for (size_t index = 0; index < AutoProc.size(); ++index)
			{
				if (!lstrcmpW(AutoProc[index].RegName, szValueName) && !lstrcmpW(AutoProc[index].RegKey, szValueKey))
				{
					flags = 1;
					break;
				}
			}
			// ��ֹ�����ظ�
			if (flags)
				continue;
			lstrcpyW(ProAu.RegName, szValueName);
			lstrcpyW(ProAu.RegKey, szValueKey);
			AutoProc.push_back(ProAu);
			wprintf(L"Name: %s\n", szValueName);
			wprintf(L"Key:\t%s\n", szValueKey);
			fwprintf(g_pFile, L"Name: %s\n", szValueName);
			fwprintf(g_pFile, L"Key:\t%s\n", szValueKey);
			fflush(g_pFile);
			ZeroMemory(szValueName, MAXBYTE);
			ZeroMemory(szValueKey, MAXBYTE);
		}
		RegCloseKey(hKey);
	}

	return 0;
}

// �ƻ�������
/*
	ͨ��WMIֻ��ö��ʹ��Win32_ScheduledJob����At.exeʵ�ó��򴴽��ļƻ�����NetScheduleJobEnum();����win8����ʧЧ
	����ʹ��Task Scheduler 2.0
*/
BOOL CheckTaskSchedulerRun()
{
	AUTOPROCESSCHECK ProAu = { 0, };
	fprintf(g_pFile, "\n%s", "�ƻ������⣺\n");
	//  ------------------------------------------------------
//  Initialize COM.
	HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
	if (FAILED(hr))
		return 1;

	//  Set general COM security levels.
	hr = CoInitializeSecurity(
		NULL,
		-1,
		NULL,
		NULL,
		RPC_C_AUTHN_LEVEL_PKT_PRIVACY,
		RPC_C_IMP_LEVEL_IMPERSONATE,
		NULL,
		0,
		NULL);

	if (FAILED(hr))
	{
		CoUninitialize();
		return 1;
	}

	//  ------------------------------------------------------
	//  Create an instance of the Task Service. 
	ITaskService *pService = NULL;
	hr = CoCreateInstance(CLSID_TaskScheduler,
		NULL,
		CLSCTX_INPROC_SERVER,
		IID_ITaskService,
		(void**)&pService);
	if (FAILED(hr))
	{
		CoUninitialize();
		return 1;
	}

	//  Connect to the task service.
	hr = pService->Connect(_variant_t(), _variant_t(),
		_variant_t(), _variant_t());
	if (FAILED(hr))
	{
		pService->Release();
		CoUninitialize();
		return 1;
	}

	//  ------------------------------------------------------
	//  Get the pointer to the root task folder.
	ITaskFolder *pRootFolder = NULL;
	hr = pService->GetFolder(_bstr_t(L"\\"), &pRootFolder);

	pService->Release();
	if (FAILED(hr))
	{
		CoUninitialize();
		return 1;
	}

	//  -------------------------------------------------------
	//  Get the registered tasks in the folder.
	IRegisteredTaskCollection* pTaskCollection = NULL;
	hr = pRootFolder->GetTasks(NULL, &pTaskCollection);

	pRootFolder->Release();
	if (FAILED(hr))
	{
		CoUninitialize();
		return 1;
	}

	LONG numTasks = 0;
	hr = pTaskCollection->get_Count(&numTasks);

	if (numTasks == 0)
	{
		pTaskCollection->Release();
		CoUninitialize();
		return 1;
	}

	fprintf(g_pFile, "�ƻ��������� : %d\n", numTasks);

	TASK_STATE taskState;

	wchar_t TaskCommand[1024] = { 0 };

	for (LONG i = 0; i < numTasks; i++)
	{
		IRegisteredTask* pRegisteredTask = NULL;
		hr = pTaskCollection->get_Item(_variant_t(i + 1), &pRegisteredTask);

		if (SUCCEEDED(hr))
		{
			BSTR taskName = NULL;
			hr = pRegisteredTask->get_Name(&taskName);
			if (SUCCEEDED(hr))
			{
				lstrcpyW(ProAu.RegName, taskName);
				fwprintf(g_pFile, L"Task Name: %s\t", taskName);

				hr = pRegisteredTask->get_State(&taskState);
				if (SUCCEEDED(hr))
					fprintf(g_pFile, "State: %d\t", taskState);

				DATE* pLastTime = NULL;
				hr = pRegisteredTask->get_LastRunTime(pLastTime);
				if (SUCCEEDED(hr))
					fwprintf(g_pFile, L"Last Time: %u\t", pLastTime);

				hr = pRegisteredTask->get_NextRunTime(pLastTime);
				if (SUCCEEDED(hr))
					fwprintf(g_pFile, L"Next Time: %u\t", pLastTime);

				hr = pRegisteredTask->get_Xml(&taskName);
				if (SUCCEEDED(hr))
				{
					XmlCommandAn((wchar_t*)taskName, TaskCommand);
					lstrcpyW(ProAu.RegKey, TaskCommand);
					fwprintf(g_pFile, L"\nִ�в���: %s\n", TaskCommand);
				}

				AutoProc.push_back(ProAu);
				SysFreeString(taskName);
			}
			pRegisteredTask->Release();
		}
	}
	pTaskCollection->Release();
	CoUninitialize();
	return 1;
}

/*
	�ű��ƻ����  gpedit.msc
*/ 
BOOL CheckScriptRun()
{
	return 1;
}
