#pragma once
#include <Windows.h>

static char TcpState[][32] =
{
	"???",
	"CLOSED",
	"LISTENING",
	"SYN_SENT",
	"SEN_RECEIVED",
	"ESTABLISHED",
	"FIN_WAIT",
	"FIN_WAIT2",
	"CLOSE_WAIT",
	"CLOSING",
	"LAST_ACK",
	"TIME_WAIT"
};

DWORD EnumTCPTable();
DWORD EnumUDPTable();
DWORD EnumTCPTablePid(int flag, DWORD pid, PVOID AutStrAddress);
DWORD EnumUDPTablePid(int flag, DWORD pid, PVOID AutStrAddress);
